# Divulgação: Apresentação do Projeto

Nesta pasta inclua arquivos de slides que foram produzidos para apresentações do projeto e de seus resultados.

