# Divulgação: Vídeo do Projeto

Nesta pasta inclua arquivos de vídeo produzidos para divulgação do projeto e seus resutados.

