  INSERT INTO Produto VALUES ('101', 'Teclado não Mecânico', 300, '3', '005');

  DELETE FROM Produto WHERE codigoProduto = '101';