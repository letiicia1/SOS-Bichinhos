package unidade00_HelloWord;

public class HelloWord {

	public static void main(String[] args) {
		System.out.println("Hello Word");

	}

}
