
Links de acesso util:

-Repositorio: https://github.com/ICEI-PUC-Minas-CC-TI/plmg-cc-ti2-2024-2-g02-sosbichinhos.git
           ou: https://github.com/ICEI-PUC-Minas-CC-TI/plmg-cc-ti2-2024-2-g02-sosbichinhos

-Pasta com os codigos: https://github.com/ICEI-PUC-Minas-CC-TI/plmg-cc-ti2-2024-2-g02-sosbichinhos/tree/master/Codigo

-Apresentação: https://www.canva.com/design/DAGUbCEY4Lc/EKRFHEHGY72_uu7MP7pNNQ/edit?utm_content=DAGUbCEY4Lc&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton
